using System;

namespace XamarinPhone
{
	public class Global
	{
		public static string Proxy = "proxy.sipthor.net";
		public static string Uname = "trinnguyen";
		public static string Passswd = "147258369";
		public static string Server = "sip2sip.info";
		public static string PhoneContact = "ostream";
	}
}

