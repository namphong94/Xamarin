using System;
using System.Drawing;
using MonoTouch.Foundation;
using MonoTouch.UIKit;
using XamSiphon.Binding;

namespace XamarinPhone
{
	public partial class MainViewController : UIViewController
	{
		private SiphonCall _siphonCall;
		private UINavigationController _navSetting;
		private SettingViewController _settingViewController;
		private int _currentCall;

		public MainViewController () : base ("MainViewController", null)
		{
			_siphonCall = new SiphonCall ();
			_settingViewController = new SettingViewController ();
			_settingViewController.SettingSaved += HandleSettingSaved;
			_navSetting = new UINavigationController (_settingViewController);
		}

		public override void DidReceiveMemoryWarning ()
		{
			// Releases the view if it doesn't have a superview.
			base.DidReceiveMemoryWarning ();

			// Release any cached data, images, etc that aren't in use.
		}

		public override void ViewDidLoad ()
		{
			base.ViewDidLoad ();
			var center = NSNotificationCenter.DefaultCenter;
			// Perform any additional setup after loading the view, typically from a nib.
			btnCall.Enabled = false;
			btnAnswer.Enabled = false;
			btnEnd.Enabled = false;

			//notifi
			center.AddObserver (new NSString("CallState"), HandleNotiFiCallState);
			center.AddObserver (new NSString("RegState"), HandleNotiFiRegState);
			//start
			Reconnect (Global.Proxy, Global.Uname, Global.Passswd, Global.Server);
		}
		private void ReloadCallStatus(string phoneContact, string phoneStatus, bool isAnswer, bool isEnd, bool isCall)
		{
			lbCallContact.Text = phoneContact;
			lbCallStatus.Text = phoneStatus;
			btnAnswer.Enabled = isAnswer;
			btnEnd.Enabled = isEnd;
			btnCall.Enabled = isCall;
		}
		#region Handler
		private void Reconnect(string proxy, string uname, string passwd, string server)	{
			string authname = uname;
			string contactname = "";
			_siphonCall.Reload (proxy, uname, authname, contactname, passwd, server);
		}
		void HandleSettingSaved (string proxy, string uname, string passwd, string server)
		{
			Reconnect (proxy, uname, passwd, server);
		}
		void actionBtnSettingsTouch (MonoTouch.Foundation.NSObject sender)	{
			this.PresentViewController(_navSetting, true, null);
		}
		#endregion
		#region NOTIFICATION
		public void HandleNotiFiRegState(NSNotification notification)	{
			NSObject statusObj = notification.UserInfo.ObjectForKey(new NSString("Status"));
			NSNumber statusNum = (NSNumber)statusObj;
			int status = statusNum.IntValue;
			Console.WriteLine ("processRegState: " + status);

			if (status == 200) {
				lbStatus.Text = "Connected - " + status;
				btnCall.Enabled = true;
			} else {
				lbStatus.Text = "Failed - " + status;
				btnCall.Enabled = false;
			}
		}
		public void HandleNotiFiCallState(NSNotification notification)	{
			NSNumber valState = (NSNumber)notification.UserInfo.ObjectForKey(new NSString("State"));
			NSNumber valCallID = (NSNumber)notification.UserInfo.ObjectForKey(new NSString("CallID"));
			NSString valRemoteInfo = (NSString)notification.UserInfo.ObjectForKey(new NSString("RemoteInfo"));

			int state = valState.IntValue;
			string remoteInfo = valRemoteInfo.ToString ();
			_currentCall = valCallID.IntValue;
			switch (state) {
			case 0://PJSIP_INV_STATE_NULL
				ReloadCallStatus ("", "PJSIP_INV_STATE_NULL", false, false, true);
				break;
			case 1://PJSIP_INV_STATE_CALLING
				ReloadCallStatus (remoteInfo, "Calling", false, true, false);
				break;
			case 2://PJSIP_INV_STATE_INCOMING
				ReloadCallStatus (remoteInfo, "Incoming", true, true, false);
				break;
			case 3://PJSIP_INV_STATE_EARLY
				ReloadCallStatus (remoteInfo, "Ringing", false, true, false);
				break;
			case 4://PJSIP_INV_STATE_CONNECTING
				ReloadCallStatus (remoteInfo, "Connecting", false, true, false);
				break;
			case 5://PJSIP_INV_STATE_CONNECTING
				ReloadCallStatus (remoteInfo, "Confirmed", false, true, false);
				break;
			case 6://PJSIP_INV_STATE_CONNECTING
				ReloadCallStatus (remoteInfo, "Disconnected", false, false, true);
				break;
			default:
				break;
			}
		}
		/**
		 * note: enum of state

		typedef enum pjsip_inv_state
		{
			PJSIP_INV_STATE_NULL,	    /**< Before INVITE is sent or received  
			PJSIP_INV_STATE_CALLING,	    /**< After INVITE is sent		    
			PJSIP_INV_STATE_INCOMING,	    /**< After INVITE is received.	    
			PJSIP_INV_STATE_EARLY,	    /**< After response with To tag.	    
			PJSIP_INV_STATE_CONNECTING,	    /**< After 2xx is sent/received.	   
			PJSIP_INV_STATE_CONFIRMED,	    /**< After ACK is sent/received.	    
			PJSIP_INV_STATE_DISCONNECTED,   /**< Session is terminated.		    
		} pjsip_inv_state;
		*/
		#endregion

		#region button handlers
		partial void btnAnswerTouch (MonoTouch.Foundation.NSObject sender)
		{
			_siphonCall.AnswerCall(_currentCall);
		}

		partial void btnCallTouch (MonoTouch.Foundation.NSObject sender)
		{
			string phoneContact = txtNumber.Text.Trim();
			_siphonCall.Dial(phoneContact);
			View.EndEditing(true);
		}

		partial void btnEndTouch (MonoTouch.Foundation.NSObject sender)
		{
			_siphonCall.EndCall(_currentCall);
		}

		partial void txtNumberEditEnd (MonoTouch.Foundation.NSObject sender)
		{

		}
		#endregion
	}
}

