// WARNING
//
// This file has been generated automatically by Xamarin Studio to store outlets and
// actions made in the UI designer. If it is removed, they will be lost.
// Manual changes to this file may not be handled correctly.
//
using MonoTouch.Foundation;
using System.CodeDom.Compiler;

namespace XamarinPhone
{
	[Register ("MainViewController")]
	partial class MainViewController
	{
		[Outlet]
		MonoTouch.UIKit.UIButton btnAnswer { get; set; }

		[Outlet]
		MonoTouch.UIKit.UIButton btnCall { get; set; }

		[Outlet]
		MonoTouch.UIKit.UIButton btnEnd { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel lbCallContact { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel lbCallStatus { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel lbStatus { get; set; }

		[Outlet]
		MonoTouch.UIKit.UITextField txtNumber { get; set; }

		[Action ("btnAnswerTouch:")]
		partial void btnAnswerTouch (MonoTouch.Foundation.NSObject sender);

		[Action ("btnCallTouch:")]
		partial void btnCallTouch (MonoTouch.Foundation.NSObject sender);

		[Action ("btnEndTouch:")]
		partial void btnEndTouch (MonoTouch.Foundation.NSObject sender);

		[Action ("txtNumberEditEnd:")]
		partial void txtNumberEditEnd (MonoTouch.Foundation.NSObject sender);
		
		void ReleaseDesignerOutlets ()
		{
			if (lbStatus != null) {
				lbStatus.Dispose ();
				lbStatus = null;
			}

			if (txtNumber != null) {
				txtNumber.Dispose ();
				txtNumber = null;
			}

			if (btnCall != null) {
				btnCall.Dispose ();
				btnCall = null;
			}

			if (lbCallContact != null) {
				lbCallContact.Dispose ();
				lbCallContact = null;
			}

			if (lbCallStatus != null) {
				lbCallStatus.Dispose ();
				lbCallStatus = null;
			}

			if (btnAnswer != null) {
				btnAnswer.Dispose ();
				btnAnswer = null;
			}

			if (btnEnd != null) {
				btnEnd.Dispose ();
				btnEnd = null;
			}
		}
	}
}
