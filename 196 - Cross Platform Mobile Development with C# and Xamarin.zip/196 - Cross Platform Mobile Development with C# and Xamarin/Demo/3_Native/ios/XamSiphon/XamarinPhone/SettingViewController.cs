using System;
using System.Collections.Generic;
using System.Linq;
using MonoTouch.Foundation;
using MonoTouch.UIKit;
using MonoTouch.Dialog;

namespace XamarinPhone
{
	public partial class SettingViewController : DialogViewController
	{
		private EntryElement _eleProxy;
		private EntryElement _eleUname;
		private EntryElement _elePassword;
		private EntryElement _eleServer;
		private StringElement _eleSave;

		public delegate void SettingSavedEvent (string proxy, string uname, string passwd, string server);
		public event SettingSavedEvent SettingSaved; 

		public SettingViewController () : base (UITableViewStyle.Grouped, null, true)
		{
			Title = "SIP Settings";
			Root = new RootElement (Title);

			//init Views
			_eleProxy = new EntryElement ("Proxy", "", Global.Proxy);
			_eleUname = new EntryElement ("Username", "", Global.Uname);
			_elePassword = new EntryElement ("Password", "", Global.Passswd);
			_eleServer = new EntryElement ("Server", "", Global.Server);
			_eleSave = new StringElement ("Save");
			_eleSave.Alignment = UITextAlignment.Center;

			_eleSave.Tapped += HandleEleSaveTapped;

			Section section = new Section ("Account");
			section.Add (_eleProxy);
			section.Add (_eleUname);
			section.Add (_elePassword);
			section.Add (_eleServer);


			Root.Add (section);

			Section section2 = new Section ();
			section2.Add (_eleSave);
			Root.Add (section2);
		}

		void HandleEleSaveTapped ()
		{
			if (SettingSaved != null) {
				SettingSaved (_eleProxy.Value, _eleUname.Value, _elePassword.Value, _eleServer.Value);
			}
			this.DismissViewController (true, null);
		}
	}
}
