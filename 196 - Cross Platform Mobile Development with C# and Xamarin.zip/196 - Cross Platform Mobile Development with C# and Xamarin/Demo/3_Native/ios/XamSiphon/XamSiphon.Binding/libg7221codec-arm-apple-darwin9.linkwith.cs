using System;
using MonoTouch.ObjCRuntime;

[assembly: LinkWith ("libg7221codec-arm-apple-darwin9.a", LinkTarget.ArmV7, ForceLoad = true)]
