using System;
using MonoTouch.ObjCRuntime;

[assembly: LinkWith ("libpjmedia-arm-apple-darwin9.a", LinkTarget.ArmV7, ForceLoad = true)]
