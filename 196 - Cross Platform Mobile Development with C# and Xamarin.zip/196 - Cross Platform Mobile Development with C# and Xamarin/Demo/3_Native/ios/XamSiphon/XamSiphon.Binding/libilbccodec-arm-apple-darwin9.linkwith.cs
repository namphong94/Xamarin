using System;
using MonoTouch.ObjCRuntime;

[assembly: LinkWith ("libilbccodec-arm-apple-darwin9.a", LinkTarget.ArmV7, ForceLoad = true)]
