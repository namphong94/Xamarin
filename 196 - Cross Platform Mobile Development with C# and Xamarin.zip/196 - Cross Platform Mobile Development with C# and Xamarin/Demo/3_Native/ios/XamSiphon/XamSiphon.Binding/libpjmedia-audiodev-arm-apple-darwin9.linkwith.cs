using System;
using MonoTouch.ObjCRuntime;

[assembly: LinkWith ("libpjmedia-audiodev-arm-apple-darwin9.a", LinkTarget.ArmV7, ForceLoad = true)]
