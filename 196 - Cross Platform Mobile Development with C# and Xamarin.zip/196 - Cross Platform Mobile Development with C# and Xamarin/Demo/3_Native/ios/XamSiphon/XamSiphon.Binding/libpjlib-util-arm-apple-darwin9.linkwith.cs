using System;
using MonoTouch.ObjCRuntime;

[assembly: LinkWith ("libpjlib-util-arm-apple-darwin9.a", LinkTarget.ArmV7, ForceLoad = true)]
