using System;
using MonoTouch.ObjCRuntime;

[assembly: LinkWith ("libpjnath-arm-apple-darwin9.a", LinkTarget.ArmV7, ForceLoad = true)]
