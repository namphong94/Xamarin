using System;
using MonoTouch.ObjCRuntime;

[assembly: LinkWith ("libmilenage-arm-apple-darwin9.a", LinkTarget.ArmV7, ForceLoad = true)]
