using System;
using MonoTouch.ObjCRuntime;

[assembly: LinkWith ("libSiphonCall.a", LinkTarget.ArmV7, ForceLoad = true, Frameworks="AVFoundation CFNetwork AudioToolbox UIKit Foundation CoreGraphics CoreMedia CoreVideo")]
