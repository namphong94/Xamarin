using System;
using MonoTouch.ObjCRuntime;

[assembly: LinkWith ("libpjsip-ua-arm-apple-darwin9.a", LinkTarget.ArmV7, ForceLoad = true)]
