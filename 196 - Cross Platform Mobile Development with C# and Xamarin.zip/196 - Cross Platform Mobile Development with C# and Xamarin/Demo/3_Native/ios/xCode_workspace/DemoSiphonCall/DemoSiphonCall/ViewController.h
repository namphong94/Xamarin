//
//  ViewController.h
//  DemoSiphonCall
//
//  Created by chuotlun on 8/9/13.
//  Copyright (c) 2013 tringuyen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SiphonCall/SiphonCall.h>

@interface ViewController : UIViewController    {
    SiphonCall *_siphonCall;
    int _currentCall;
}

@property (unsafe_unretained, nonatomic) IBOutlet UIButton *btnCall;
@property (unsafe_unretained, nonatomic) IBOutlet UITextField *txtNumber;
@property (unsafe_unretained, nonatomic) IBOutlet UILabel *lbContactNumber;
@property (unsafe_unretained, nonatomic) IBOutlet UILabel *lbCallStatus;
@property (unsafe_unretained, nonatomic) IBOutlet UILabel *lbStatus;
- (IBAction)actionBtnCallTouch:(id)sender;
- (IBAction)actionAnswerTouch:(id)sender;
- (IBAction)actionEndCallTouch:(id)sender;
- (IBAction)txtNumberDidEnded:(id)sender;

@end
