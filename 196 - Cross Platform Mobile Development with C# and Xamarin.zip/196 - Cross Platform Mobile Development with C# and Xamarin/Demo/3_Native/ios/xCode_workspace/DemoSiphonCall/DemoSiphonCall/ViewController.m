//
//  ViewController.m
//  DemoSiphonCall
//
//  Created by chuotlun on 8/9/13.
//  Copyright (c) 2013 tringuyen. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    //Notify
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(processCallState:)
                                                 name: @"CallState" object:nil];
    
    /** Registration management */
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(processRegState:)
                                                 name: @"RegState" object:nil];
    
    //siphoncall
    _siphonCall = [[SiphonCall alloc] init];
    
    //load Config values
    NSString* val_proxies = @"proxy.sipthor.net";
    NSString* uname = @"trinnguyen";
    NSString* authname = @"trinnguyen";
    NSString* contactname = nil;
    NSString* passwd = @"147258369";
    NSString* server = @"sip2sip.info";
    
    [_siphonCall reloadWithProxy:val_proxies uname:uname authname:authname contactname:contactname passwd:passwd server:server];
}
- (void) reloadCallStatus:(NSString*) val   {
    self.lbCallStatus.text = val;
}
- (void) reloadCallContact:(NSString*) val   {
    self.lbContactNumber.text = val;
}
//handler NOTIFY
- (void)processCallState:(NSNotification *)notification
{
#if 0
    NSNumber *value = [[ notification userInfo ] objectForKey: @"CallID"];
    pjsua_call_id callId = [value intValue];
#endif
    int state = [[[ notification userInfo ] objectForKey: @"State"] intValue];
    NSDictionary *userInfo = [notification userInfo];
    _currentCall = [[userInfo objectForKey:@"CallID"] integerValue];
    NSLog(@"--------------processCallState: -------------");
    NSLog(@"%@",userInfo);
    switch(state)
    {
        case PJSIP_INV_STATE_NULL: // Before INVITE is sent or received.
            NSLog(@"PJSIP_INV_STATE_NULL");
            [self reloadCallStatus:@"PJSIP_INV_STATE_NULL"];
            return;
        case PJSIP_INV_STATE_CALLING: // After INVITE is sent.
            NSLog(@"PJSIP_INV_STATE_CALLING");
            
            [self reloadCallContact:[userInfo objectForKey:@"RemoteInfo"]];
            [self reloadCallStatus:@"Calling"];
#ifdef __IPHONE_3_0
            [UIDevice currentDevice].proximityMonitoringEnabled = YES;
#else
            self.proximitySensingEnabled = YES;
#endif
            break;
        case PJSIP_INV_STATE_INCOMING:
            NSLog(@"PJSIP_INV_STATE_INCOMING");
            [self reloadCallContact:[userInfo objectForKey:@"RemoteInfo"]];
            [self reloadCallStatus:@"Incoming"];
            break;
        case PJSIP_INV_STATE_EARLY: // After response with To tag.
            NSLog(@"PJSIP_INV_STATE_EARLY");
            [self reloadCallContact:[userInfo objectForKey:@"RemoteInfo"]];
            [self reloadCallStatus:@"Ringing"];
            break;
        case PJSIP_INV_STATE_CONNECTING: // After 2xx is sent/received.
            NSLog(@"PJSIP_INV_STATE_CONNECTING");
            [self reloadCallContact:[userInfo objectForKey:@"RemoteInfo"]];
            [self reloadCallStatus:@"Connecting"];
            break;
        case PJSIP_INV_STATE_CONFIRMED: // After ACK is sent/received.
            NSLog(@"PJSIP_INV_STATE_CONFIRMED");
            [self reloadCallContact:[userInfo objectForKey:@"RemoteInfo"]];
            [self reloadCallStatus:@"Confirmed"];
#ifdef __IPHONE_3_0
            [UIDevice currentDevice].proximityMonitoringEnabled = YES;
#else
            self.proximitySensingEnabled = YES;
#endif
            break;
        case PJSIP_INV_STATE_DISCONNECTED:
            NSLog(@"PJSIP_INV_STATE_DISCONNECTED");
            [self reloadCallContact:[userInfo objectForKey:@"RemoteInfo"]];
            [self reloadCallStatus:@"Disconnected"];
#if 0
            self.idleTimerDisabled = NO;
#ifdef __IPHONE_3_0
            [UIDevice currentDevice].proximityMonitoringEnabled = NO;
#else
            self.proximitySensingEnabled = NO;
#endif
            if (pjsua_call_get_count() <= 1)
                [self performSelector:@selector(disconnected:)
                           withObject:nil afterDelay:1.0];
#endif
            break;
    }
    //[callViewController processCall: [ notification userInfo ]];
    NSLog(@"--------------END: -------------");
}
- (void)processRegState:(NSNotification *)notification
{
    int status = [[[ notification userInfo ] objectForKey: @"Status"] intValue];
    NSLog(@"processRegState: %d", status);
    switch(status)
    {
        case 200: // OK
            //isConnected = TRUE;
            self.lbStatus.text = @"Connected 200";
            self.btnCall.enabled = YES;
            break;
        case 403: // registration failed
            self.lbStatus.text = @"Failed 403";
            break;
        case 404: // not found
            self.lbStatus.text = @"Failed 404";
            break;
        case 503:
            self.lbStatus.text = @"Failed 503";
            break;
        case PJSIP_ENOCREDENTIAL:
            self.lbStatus.text = @"Failed PJSIP_ENOCREDENTIAL";
            break;
        default:
            //isConnected = FALSE;
            break;
    }
}

//END NOTIFY

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
    [self setTxtNumber:nil];
    [self setBtnCall:nil];
    [self setLbContactNumber:nil];
    [self setLbCallStatus:nil];
    [self setLbStatus:nil];
    [super viewDidUnload];
}
- (IBAction)actionBtnCallTouch:(id)sender {
    NSString* phoneNumber = self.txtNumber.text;
    [_siphonCall dial:phoneNumber];
}

- (IBAction)actionAnswerTouch:(id)sender {
    [_siphonCall answerCall:_currentCall];
}

- (IBAction)actionEndCallTouch:(id)sender {
    [_siphonCall endCall:_currentCall];
}

- (IBAction)txtNumberDidEnded:(id)sender {
    [self.txtNumber resignFirstResponder];
}
@end
