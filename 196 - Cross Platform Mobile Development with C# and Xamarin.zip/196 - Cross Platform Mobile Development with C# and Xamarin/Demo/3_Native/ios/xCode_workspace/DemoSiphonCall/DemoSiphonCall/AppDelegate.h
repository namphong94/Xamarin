//
//  AppDelegate.h
//  DemoSiphonCall
//
//  Created by chuotlun on 8/9/13.
//  Copyright (c) 2013 tringuyen. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
