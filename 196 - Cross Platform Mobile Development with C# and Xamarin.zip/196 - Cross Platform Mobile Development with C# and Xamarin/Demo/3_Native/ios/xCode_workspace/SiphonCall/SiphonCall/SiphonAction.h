//
//  SiphonAction.h
//  SiphonCall
//
//  Created by chuotlun on 8/9/13.
//  Copyright (c) 2013 tringuyen. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "call.h"

@interface SiphonAction : NSObject     {
    app_config_t _app_config; // pointer ???
    pjsua_acc_id  _sip_acc_id;
}

//config values

@property(nonatomic, retain) NSString *val_proxies; // "proxy.sipthor.net"
@property(nonatomic, retain) NSString *uname; // "trinnguyen"
@property(nonatomic, retain) NSString *authname; // "trinnguyen"
@property(nonatomic, retain) NSString *contactname; // NULL
@property(nonatomic, retain) NSString *passwd; // "147258369"
@property(nonatomic, retain) NSString *server; // "sip2sip.info"

//end values

@property(nonatomic,assign) BOOL networkActivityIndicatorVisible;

+ (SiphonAction*) getInstance;
- (void) startWithProxy:(NSString*) valProxy uname:(NSString*) valUname authname:(NSString*)valAuthname contactname:(NSString*) valContactname passwd:(NSString*) valPasswd server:(NSString*)valServer;
- (app_config_t *)pjsipConfig;
- (void) dial:(NSString*)phoneNumber;
- (void) endCall:(int) currentCall;
- (void) answerCall: (int)  currentCall;

@end
