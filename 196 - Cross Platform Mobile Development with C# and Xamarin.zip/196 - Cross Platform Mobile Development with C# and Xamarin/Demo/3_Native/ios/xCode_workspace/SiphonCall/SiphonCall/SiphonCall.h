//
//  SiphonCall.h
//  SiphonCall
//
//  Created by chuotlun on 8/9/13.
//  Copyright (c) 2013 tringuyen. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SiphonAction.h"

@interface SiphonCall : NSObject    {
    SiphonAction* _siphonAction;
}

//public functions
- (void) reloadWithProxy:(NSString*) valProxy uname:(NSString*) valUname authname:(NSString*)valAuthname contactname:(NSString*) valContactname passwd:(NSString*) valPasswd server:(NSString*)valServer;
- (void) dial: (NSString*) phoneNumber;
- (void) endCall:(int) currentCall;
- (void) answerCall: (int)  currentCall;
@end
