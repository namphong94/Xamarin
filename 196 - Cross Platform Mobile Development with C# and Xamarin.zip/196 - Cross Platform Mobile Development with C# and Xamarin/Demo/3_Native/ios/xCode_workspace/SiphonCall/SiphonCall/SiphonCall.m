//
//  SiphonCall.m
//  SiphonCall
//
//  Created by chuotlun on 8/9/13.
//  Copyright (c) 2013 tringuyen. All rights reserved.
//

#import "SiphonCall.h"

@implementation SiphonCall

//public functions
- (id) init {
    self = [super init];
    if (self != nil)    {
        _siphonAction = [SiphonAction getInstance];
    }
    return self;
}
- (void) reloadWithProxy:(NSString*) valProxy uname:(NSString*) valUname authname:(NSString*)valAuthname contactname:(NSString*) valContactname passwd:(NSString*) valPasswd server:(NSString*)valServer    {
    [_siphonAction startWithProxy:valProxy uname:valUname authname:valAuthname contactname:valContactname passwd:valPasswd server:valServer];
}
- (void) dial: (NSString*) phoneNumber  {
    [_siphonAction dial:phoneNumber];
}
- (void) endCall:(int) currentCall  {
    [_siphonAction endCall:currentCall];
}
- (void) answerCall: (int)  currentCall {
    [_siphonAction answerCall:currentCall];
}
@end
