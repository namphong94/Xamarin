//
//  SiphonAction.m
//  SiphonCall
//
//  Created by chuotlun on 8/9/13.
//  Copyright (c) 2013 tringuyen. All rights reserved.
//

#import "SiphonAction.h"

@implementation SiphonAction
@synthesize networkActivityIndicatorVisible, val_proxies, uname, contactname, passwd, server;

static SiphonAction* _instance;
+ (SiphonAction*) getInstance   {
    if (_instance == nil) {
        _instance = [[SiphonAction alloc] init];
    }
    return _instance;
}
- (void) startWithProxy:(NSString*) valProxy uname:(NSString*) valUname authname:(NSString*)valAuthname contactname:(NSString*) valContactname passwd:(NSString*) valPasswd server:(NSString*)valServer {
    
    //reload config values
    self.val_proxies = valProxy;
    self.uname = valUname;
    self.authname = valAuthname;
    self.contactname = valContactname;
    self.passwd = valPasswd;
    self.server = valServer;
    
    //reconnect to server
    _sip_acc_id = PJSUA_INVALID_ID;
    [self performSelector:@selector(sipConnect) withObject:nil afterDelay:0.2];
}
- (app_config_t *)pjsipConfig
{
    return &_app_config;
}
- (void) dial:(NSString*)phoneNumber    {
    pjsua_call_id call_id;
    pj_status_t status;
    
    UInt32 hasMicro, size;
    
    // Verify if microphone is available (perhaps we should verify in another place ?)
    size = sizeof(hasMicro);
    AudioSessionGetProperty(kAudioSessionProperty_AudioInputAvailable,
                            &size, &hasMicro);
    if (!hasMicro)
    {
        NSLog(@"No Microphone Available");
        return;
    }
    if ([self sipConnect])
    {
        NSRange range = [phoneNumber rangeOfString:@"@"];
        if (range.location != NSNotFound)
        {
            status = sip_dial_with_uri(_sip_acc_id, [[NSString stringWithFormat:@"sip:%@", phoneNumber] UTF8String], &call_id);
        }
        else
            status = sip_dial(_sip_acc_id, [phoneNumber UTF8String], &call_id);
        if (status != PJ_SUCCESS)
        {
            // FIXME
            //[self displayStatus:status withTitle:nil];
            const pj_str_t *str = pjsip_get_status_text(status);
            NSString *msg = [[NSString alloc]
                             initWithBytes:str->ptr
                             length:str->slen
                             encoding:[NSString defaultCStringEncoding]];
            NSLog(@"registration error: %@", msg);
        }
        else    {
            NSLog(@"status PJ_SUCCESS");
        }
    }
}
- (void) endCall:(int) currentCall {
    pjsua_call_id cid = (pjsua_call_id)currentCall;
    sip_hangup(&cid);
}
- (void) answerCall: (int)  currentCall {
    pjsua_call_id cid = (pjsua_call_id)currentCall;
    sip_answer(&cid);
}

//internal methods SIP
- (BOOL)sipStartup
{
    if (_app_config.pool)
        return YES;
    self.networkActivityIndicatorVisible = YES;
    if (sip_startup(&_app_config) != PJ_SUCCESS)
    {
        self.networkActivityIndicatorVisible = NO;
        return NO;
    }
    self.networkActivityIndicatorVisible = NO;
    return YES;
}
- (void)sipCleanup
{
    [self sipDisconnect];
    if (_app_config.pool != NULL)
    {
        sip_cleanup(&_app_config);
    }
}
- (BOOL)sipConnect
{
    pj_status_t status;
    
    if (![self sipStartup])
        return FALSE;
    if (_sip_acc_id == PJSUA_INVALID_ID)
    {
        self.networkActivityIndicatorVisible = YES;
        if ((status = sip_connect(_app_config.pool, &_sip_acc_id)) != PJ_SUCCESS)
        {
            self.networkActivityIndicatorVisible = NO;
            return FALSE;
        }
    }
    return TRUE;
}
- (BOOL)sipDisconnect
{
    if ((_sip_acc_id != PJSUA_INVALID_ID) &&
        (sip_disconnect(&_sip_acc_id) != PJ_SUCCESS))
    {
        return FALSE;
    }
    _sip_acc_id = PJSUA_INVALID_ID;
    return TRUE;
}
//end internal SIP

@end
