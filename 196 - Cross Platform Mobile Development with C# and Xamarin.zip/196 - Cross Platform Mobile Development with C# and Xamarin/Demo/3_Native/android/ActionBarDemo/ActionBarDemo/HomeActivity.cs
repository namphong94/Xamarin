using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using FragmentTransaction = Android.Support.V4.App.FragmentTransaction;
using SherlockActionBar = Com.Actionbarsherlock.App.ActionBar;

namespace ActionBarDemo
{
    [Activity(Label = "ActionBarDemo", MainLauncher = true)]
    public class HomeActivity : Com.Actionbarsherlock.App.SherlockActivity, SherlockActionBar.ITabListener
    {
        protected override void OnCreate(Bundle bundle)
        {
            SetTheme(Resource.Style.Sherlock___Theme);
            base.OnCreate(bundle);
            SetContentView(Resource.Layout.Main);
            SupportActionBar.NavigationMode = SherlockActionBar.NavigationModeTabs;

            for (int i = 0; i < 3; i++ )
            {
                var tab = SupportActionBar.NewTab();
                tab.SetText("Tab " + i);
                tab.SetTabListener(this);
                SupportActionBar.AddTab(tab);
            }
        }

        public void OnTabReselected(SherlockActionBar.Tab p0, FragmentTransaction p1)
        {
            
        }

        public void OnTabSelected(SherlockActionBar.Tab p0, FragmentTransaction p1)
        {
            
        }

        public void OnTabUnselected(SherlockActionBar.Tab p0, FragmentTransaction p1)
        {
            
        }
    }
}