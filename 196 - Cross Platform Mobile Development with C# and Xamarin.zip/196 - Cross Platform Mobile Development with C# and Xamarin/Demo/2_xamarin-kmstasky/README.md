xamarin-kmstasky
================

custom project Tasky of Xamarin for using in a public seminar
+ Sharing Business code (how to design architure of cross-platform app
+ Demo work with Database (Data Layer)
+ App GUI (iOS & Android)
